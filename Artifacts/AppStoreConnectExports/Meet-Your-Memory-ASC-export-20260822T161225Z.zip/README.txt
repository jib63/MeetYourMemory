App Store Connect Analytics export

This archive contains App Store context, Apple's tab-delimited Analytics data, optional filtered Sales & Trends reports, and a manifest. It contains no App Store Connect API key, issuer credential, vendor number, private-key path, or signed token.

Usage and crash reports may be empty for a low-volume app because Apple only reports opted-in data that clears its privacy thresholds.
